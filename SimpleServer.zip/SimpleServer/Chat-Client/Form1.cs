﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.IO;

namespace Chat_Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            TcpClient tcpClient = new TcpClient();
            InitializeComponent();
        }
        private TcpClient tcpClient = new TcpClient();
        private StreamWriter writer;
        private StreamReader reader;
        private NetworkStream stream;

        public bool Connect(String ipAddress, int port)
        {
            try
            {
                tcpClient.Connect("127.0.0.1", 4444);
                stream = tcpClient.GetStream();
                reader = new StreamReader(stream, System.Text.Encoding.UTF8);
                writer = new StreamWriter(stream, System.Text.Encoding.UTF8);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
                return false;
            }
            return true;
        }

        public void Run()
        {
            String userInput = "";
            ProcessServerResponse();

            while ((userInput = Console.ReadLine()) != null)
            {
                writer.WriteLine(userInput);
                writer.Flush();
                ProcessServerResponse();
                if (userInput == "9")
                {
                    break;
                }
            }
            tcpClient.Close();
        }

        private void ProcessServerResponse()
        {
            Console.WriteLine("Server says : " + reader.ReadLine());
            Console.WriteLine();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string message = textBox1.Text;
        }
    }
}
