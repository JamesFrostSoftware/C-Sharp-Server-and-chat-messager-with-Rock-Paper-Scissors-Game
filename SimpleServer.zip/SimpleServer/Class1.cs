﻿using System;
using 

public class Class1
{
	public Class1()
	{
        TcpListener tcpListener;

        public Class1(string ipAddress, int port)
        {
            ipAddress = IPAddress.Parse(ipAddress);
            //tcpListener(int Port);
        }

        public Start()
        {

        }

        public Stop()
        {

        }

        private static SocketMethod(Socket socket)
        {

        }

        private static string GetReturnMessage(string code)
        {

        }
    }
}
