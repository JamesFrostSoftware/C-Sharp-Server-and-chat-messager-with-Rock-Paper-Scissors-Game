﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Packets
{
    public enum PacketType
    {
        EMPTY, NICKNAME, CHATMESSAGE, RESULT, WINNER, RESET
    }
}
