﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DiningPhilosophers
{
    public class Philo
    {
        int n;
        int thinkDelay;
        int eatDelay;
        int left, right;
        p_fork p_fork;
        private BinaryWriter writer;
        private BinaryReader reader;

        public Philo(int n, int thinkDelay, int eatDelay, p_fork p_fork)
        {
            this.n = n;
            this.thinkDelay = thinkDelay;
            this.eatDelay = eatDelay;
            this.p_fork = p_fork;

            left = n == 0 ? 4 : n - 1;
            right = (n + 1) % 5;
            new Thread(new ThreadStart(Run)).Start();
        }

        public void Run()
        {
            for(; ; )
            {
                try
                {
                    Thread.Sleep(thinkDelay);
                    p_fork.Get(left, right);
                    Console.Write("Philosopher " + n + " is eating...");
                    Console.ReadLine();
                    Thread.Sleep(eatDelay);
                    p_fork.Put(left, right);
                }
                catch
                {
                    return;
                }
            }
        }
    }
}
