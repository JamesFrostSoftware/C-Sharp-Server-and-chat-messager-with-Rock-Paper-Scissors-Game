﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DiningPhilosophers
{
    public class p_fork
    {
        bool[] fork = new bool[5];

        public void Get(int left, int right)
        {
            lock (this)
            {
                while (fork[left] || fork[right]) Monitor.Wait(this);
                fork[left] = true; fork[right] = true;
            }
        }

        public void Put(int left, int right)
        {
            lock (this)
            {
                fork[left] = false; fork[right] = false;
                Monitor.PulseAll(this);
            }
        }
    }
}
